<?php
include 'koneksi.php';
?>
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include 'koneksi.php';
?>

<div class="card card-primary">
    <div class="card-header">
        <h3 class="card-title">
            <i class="fa fa-edit"></i> Tambah Data
        </h3>
    </div>
    <form action="" method="post" enctype="multipart/form-data">
        <div class="card-body">
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Nama</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" id="nama" name="nama" placeholder="Nama Penduduk" required>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Umur</label>
                <div class="col-sm-6">
                    <input type="date" class="form-control" id="umur" name="umur" required>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Agama</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" id="agama" name="agama" placeholder="Agama" required>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Jenis Kelamin</label>
                <div class="col-sm-3">
                    <select name="jekel" id="jekel" class="form-control" required>
                        <option value="">- Pilih -</option>
                        <option value="LK">LK</option>
                        <option value="PR">PR</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <input type="submit" name="Simpan" value="Simpan" class="btn btn-info">
            <a href="?page=data-izin" title="Kembali" class="btn btn-secondary">Batal</a>
        </div>
    </form>
</div>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php
if (isset($_POST['Simpan'])) {
    $sql_simpan = "INSERT INTO tb_gender (nama, umur, agama, kelamin) VALUES (
        '" . $_POST['nama'] . "',
        '" . $_POST['umur'] . "',
        '" . $_POST['agama'] . "',
        '" . $_POST['jekel'] . "'
    )";

    $query_simpan = mysqli_query($koneksi, $sql_simpan);
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        echo "<pre>";
        print_r($_POST); // Untuk memastikan data terkirim
        echo "</pre>";
    }

    if ($query_simpan) {
        echo "<script>
      Swal.fire({title: 'Tambah Data Berhasil',text: '',icon: 'success',confirmButtonText: 'OK'
      }).then((result) => {if (result.value){
          window.location = 'index.php?page=data-izin';
          }
      })</script>";
    } else {
        echo "<script>
      Swal.fire({title: 'Tambah Data Gagal',text: '" . mysqli_error($koneksi) . "',icon: 'error',confirmButtonText: 'OK'
      }).then((result) => {if (result.value){
          window.location = 'index.php?page=data-izin';
          }
      })</script>";
    }
}
?>