# [SISTEM DATA KEPENDUDUKAN PERUM WALIKOTA BLOK N 13 RT 04 RW 06 DESA CIBEUTEUNG MUARA KECAMATAN CISEENG KAB.BOGOR]
**Sistem Data Kependudukan (SIDAK)** merupakan Sistem Administrasi Kependudukan yang dikelola oleh badan pemerintahan Desa Tamantirto

